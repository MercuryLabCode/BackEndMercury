<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ciudad_departamento extends Model
{
    protected $table = 't_ciudades_colombia';
    protected $primaryKey = 'PRIMARY';
    protected $keyType = 'string';

}
