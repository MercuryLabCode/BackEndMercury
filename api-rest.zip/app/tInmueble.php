<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tInmueble extends Model
{
    protected $table = 't_tipo_inmueble';

}
