<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ordenesCompra extends Model
{
    protected $table = 't_ordenes_compra';
    protected $primaryKey = 'PRIMARY';
    public $timestamps = false;
  

}
