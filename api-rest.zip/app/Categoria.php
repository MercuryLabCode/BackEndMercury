<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categoria extends Model
{
    protected $table = 't_estado_categoria';
    protected $primaryKey = 'Catalogo_Estado_categoria';
    protected $keyType = 'string';

}
